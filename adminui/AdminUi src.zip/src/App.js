import logo from './logo.svg';
import './App.css';
import Admin from './Components/Admin';

function App() {
  return (
    <div className="App">
      <Admin/>
    </div>
  );
}

export default App;
